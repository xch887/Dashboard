import { Suspense } from "react";
import { DashboardPageContent } from "@/components/dashboard/dashboard-page-content";

export default function DashboardPage() {
  return (
    <>
      <section
        className="relative border-b border-slate-200/80 pb-5"
        aria-labelledby="dashboard-heading"
      >
        <div
          className="absolute left-0 top-0 h-1 w-16 rounded-full bg-blue-600 md:w-24"
          aria-hidden
        />
        <p className="pt-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-blue-800">
          Live operations
        </p>
        <h1
          id="dashboard-heading"
          className="mt-2 text-balance text-3xl font-extrabold tracking-tight text-slate-950 md:text-4xl"
        >
          Fleet readiness
        </h1>
        <p className="mt-2 max-w-2xl text-pretty text-[15px] leading-relaxed text-slate-600 md:text-base">
          Predictive signals, open actions, and compliance context in one
          view—prioritize what needs a human before the next shift.
        </p>
      </section>

      <Suspense
        fallback={
          <p className="mt-8 text-sm text-slate-500">Loading dashboard…</p>
        }
      >
        <DashboardPageContent />
      </Suspense>
    </>
  );
}
